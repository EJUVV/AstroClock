import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { meuPerfil, sair } from '../compartilhado/api/auth.ts'
import Fundo from '../compartilhado/ui/Fundo.tsx'
import { botaoPrincipal } from '../compartilhado/ui/estilos.ts'
import { Carregando } from '../compartilhado/ui/Estados.tsx'

function Inicio() {
  const navigate = useNavigate()
  const [estado, setEstado] = useState<'carregando' | 'negado' | 'erro'>('carregando')
  const [erro, setErro] = useState('')

  useEffect(() => {
    meuPerfil()
      .then((perfil) => {
        if (perfil === 'membro') navigate('/membro', { replace: true })
        else if (perfil === 'rh' || perfil === 'diretor_rh') navigate('/rh', { replace: true })
        else setEstado('negado')
      })
      .catch((e: Error) => {
        setErro(e.message)
        setEstado('erro')
      })
  }, [navigate])

  return (
    <Fundo variante="brilho">
      <main className="relative mx-auto flex min-h-screen max-w-sm flex-col items-center justify-center gap-4 px-7 text-center">
        {estado === 'carregando' ? (
          <Carregando texto="Carregando..." />
        ) : (
          <>
            <p className="font-mono text-[11px] uppercase tracking-[0.3em] text-purple-300">AstroClock · EJUVV</p>
            <p role="alert" className="text-2xl font-light">
              {estado === 'negado' ? 'Acesso negado. Procure o RH.' : erro}
            </p>
            <button type="button" onClick={() => void sair()} className={`${botaoPrincipal} mt-2 w-full`}>
              Voltar
            </button>
          </>
        )}
      </main>
    </Fundo>
  )
}

export default Inicio
