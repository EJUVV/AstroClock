import { useCallback, useEffect, useState } from 'react'
import { meuNome, sair } from '../compartilhado/api/auth.ts'
import { cronometroAtivo, iniciarCronometro, pararCronometro } from '../compartilhado/api/cronometro.ts'
import { desmarcarNaSede, estouNaSede, marcarNaSede, quemEstaNaSede } from '../compartilhado/api/presenca.ts'
import { horasPorDia, minhaPosicaoNoRanking, progressoDaSemana, progressoDoMes } from '../compartilhado/api/progresso.ts'
import { buscarMeusRegistros, cancelarRegistro } from '../compartilhado/api/registros.ts'
import { hora, horas, mesDe, nomeDoMes, rotuloDia, rotuloSemana, semanaAtual, tempoQueJaPassou, dataEmBrasilia } from '../compartilhado/datas.ts'
import type { HorasDoDia, Local, PosicaoRanking, PresencaSede, ProgressoSemana, Registro } from '../compartilhado/tipos.ts'
import Cartao from '../compartilhado/ui/Cartao.tsx'
import { Carregando, Erro } from '../compartilhado/ui/Estados.tsx'
import Etiqueta from '../compartilhado/ui/Etiqueta.tsx'
import Fundo from '../compartilhado/ui/Fundo.tsx'
import Planeta from '../compartilhado/ui/Planeta.tsx'
import { botao, botaoMarcado, botaoPrincipal, botaoVerde, campo } from '../compartilhado/ui/estilos.ts'

interface Dados {
  nome: string
  progresso: ProgressoSemana
  ativo: Registro | null
  registros: Registro[]
  dias: HorasDoDia[]
  posicao: PosicaoRanking
  semanasDoMes: ProgressoSemana[]
  presentes: PresencaSede[]
  naSede: boolean
}

const DIAS = ['S', 'T', 'Q', 'Q', 'S', 'S', 'D']

function formatar(segundos: number) {
  const p = (n: number) => String(n).padStart(2, '0')
  return `${p(Math.floor(segundos / 3600))}:${p(Math.floor((segundos % 3600) / 60))}:${p(segundos % 60)}`
}

function Barra({ rotulo, valor, meta }: { rotulo: string; valor: number; meta: number }) {
  const pct = meta === 0 ? 100 : Math.min(100, Math.round((valor / meta) * 100))
  return (
    <div>
      <div className="mb-2 flex justify-between">
        <b className="font-semibold">{rotulo}</b>
        <span className="font-mono text-sm text-white/70">
          {horas(valor)}h / {horas(meta)}h
        </span>
      </div>
      <div className="h-2.5 overflow-hidden rounded-full bg-white/10">
        <div
          className="h-full rounded-full bg-gradient-to-r from-[#7c3aed] to-[#d8b4fe] shadow-[0_0_14px_rgba(168,85,247,0.8)]"
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  )
}

function EtiquetaSemana({ s, atual }: { s: ProgressoSemana; atual: string }) {
  if (s.dispensada) return <Etiqueta tom="neutro">Dispensada</Etiqueta>
  if (s.cumpriu) return <Etiqueta tom="ok">Cumpriu</Etiqueta>
  if (s.semana > atual) return <Etiqueta tom="neutro">Futura</Etiqueta>
  if (s.semana === atual) return <Etiqueta tom="alerta">Em andamento</Etiqueta>
  return <Etiqueta tom="ruim">Abaixo da meta</Etiqueta>
}

function PainelMembro() {
  const semana = semanaAtual()
  const mes = mesDe(semana)
  const [dados, setDados] = useState<Dados | null>(null)
  const [erro, setErro] = useState<string | null>(null)
  const [erroAcao, setErroAcao] = useState<string | null>(null)
  const [local, setLocal] = useState<Local>('sede')
  const [descricao, setDescricao] = useState('')
  const [agora, setAgora] = useState(() => Date.now())

  const carregar = useCallback(() => {
    Promise.all([
      meuNome(),
      progressoDaSemana(semana),
      cronometroAtivo(),
      buscarMeusRegistros(semana),
      horasPorDia(semana),
      minhaPosicaoNoRanking(mes),
      progressoDoMes(mes),
      quemEstaNaSede(),
      estouNaSede(),
    ])
      .then(([nome, progresso, ativo, registros, dias, posicao, semanasDoMes, presentes, naSede]) => {
        setErro(null)
        setDados({ nome, progresso, ativo, registros, dias, posicao, semanasDoMes, presentes, naSede })
      })
      .catch((e: Error) => setErro(e.message))
  }, [semana, mes])

  useEffect(() => {
    carregar()
  }, [carregar])

  const cronometroLigado = dados?.ativo != null
  useEffect(() => {
    if (!cronometroLigado) return
    const id = setInterval(() => setAgora(Date.now()), 1000)
    return () => clearInterval(id)
  }, [cronometroLigado])

  // Executa uma ação (iniciar, parar, cancelar...), mostra o erro dela e recarrega a tela.
  function acao(fazer: () => Promise<unknown>, depois?: () => void) {
    setErroAcao(null)
    fazer()
      .then(() => {
        depois?.()
        carregar()
      })
      .catch((e: Error) => setErroAcao(e.message))
  }

  if (erro) {
    return (
      <Fundo variante="arco">
        <main className="relative">
          <Erro
            mensagem={erro}
            aoTentar={() => {
              setErro(null)
              carregar()
            }}
          />
        </main>
      </Fundo>
    )
  }
  if (!dados) {
    return (
      <Fundo variante="arco">
        <main className="relative">
          <Carregando />
        </main>
      </Fundo>
    )
  }

  const { progresso, ativo } = dados
  const faltaSede = Math.max(0, progresso.metaSede - progresso.horasSede)
  const faltaTotal = Math.max(0, progresso.metaTotal - progresso.horasTotal)
  const segundos = ativo ? Math.max(0, Math.floor((agora - Date.parse(ativo.inicio)) / 1000)) : 0
  const maiorDia = Math.max(1, ...dados.dias.map((d) => d.horasTotal))
  const ateAgora = dados.semanasDoMes.filter((s) => s.semana <= semana)
  const contadas = ateAgora.filter((s) => !s.dispensada)
  const nomesNaSede = dados.presentes.map((p) => p.nome.split(' ')[0])

  return (
    <Fundo variante="arco">
      <main className="relative mx-auto flex max-w-5xl flex-col gap-4 px-5 pb-16 pt-6">
        <header className="flex items-start justify-between gap-3">
          <div>
            <p className="font-mono text-[11px] uppercase tracking-[0.3em] text-purple-300">AstroClock · EJUVV</p>
            <p className="mt-6 text-sm text-white/70">Bem-vindo</p>
            <h1 className="text-3xl font-light tracking-tight sm:text-4xl">
              Olá, <span className="italic text-[#c084fc]">{dados.nome}</span>
            </h1>
          </div>
          <div className="flex items-start gap-10">
            <Planeta tamanho={80} className="hidden md:block" />
            <button type="button" onClick={() => void sair()} className={`${botao} min-h-11`}>
              Sair
            </button>
          </div>
        </header>

        {erroAcao && (
          <p role="alert" className="rounded-xl border border-rose-400/50 bg-rose-400/10 px-4 py-3 text-rose-200">
            {erroAcao}
          </p>
        )}

        <div className="grid gap-4 md:grid-cols-2">
          <Cartao titulo={`Semana de ${rotuloSemana(semana)}`} className="md:col-span-2">
            {progresso.dispensada ? (
              <Etiqueta tom="neutro">Semana dispensada</Etiqueta>
            ) : progresso.cumpriu ? (
              <Etiqueta tom="ok">Meta cumprida</Etiqueta>
            ) : (
              <Etiqueta tom="alerta">Ainda não cumpriu</Etiqueta>
            )}
            <div className="grid gap-4 md:grid-cols-2">
              <Barra rotulo="Horas na sede" valor={progresso.horasSede} meta={progresso.metaSede} />
              <Barra rotulo="Horas totais" valor={progresso.horasTotal} meta={progresso.metaTotal} />
            </div>
            <p className="text-sm text-white/70">
              Horas online não compensam as da sede.
              {!progresso.cumpriu &&
                !progresso.dispensada &&
                ` Faltam ${horas(faltaSede)}h na sede e ${horas(faltaTotal)}h no total.`}
            </p>
          </Cartao>

          <section className="flex flex-col gap-3 rounded-2xl border border-[#c084fc]/50 bg-gradient-to-br from-[#5b21b6] to-[#2e0f8f] p-4 shadow-[0_0_40px_rgba(124,58,237,0.35)]">
            <h2 className="text-base font-semibold">Cronômetro</h2>
            <p
              className={`text-center font-mono text-5xl font-light tabular-nums ${ativo ? 'text-white' : 'text-white/80'}`}
              role="timer"
              aria-live="off"
            >
              {formatar(segundos)}
            </p>
            <div className="flex gap-2">
              {(['sede', 'online'] as const).map((l) => {
                const marcado = (ativo ? ativo.local : local) === l
                return (
                  <button
                    key={l}
                    type="button"
                    aria-pressed={marcado}
                    disabled={ativo != null}
                    onClick={() => setLocal(l)}
                    className={`${marcado ? botaoMarcado : botao} flex-1 capitalize`}
                  >
                    {l}
                  </button>
                )
              })}
            </div>
            {ativo ? (
              <p className="min-h-12 rounded-xl border border-white/25 bg-black/25 px-3 py-3 text-white/90">
                {ativo.descricao}
              </p>
            ) : (
              <input
                aria-label="Descrição"
                placeholder="O que você vai fazer?"
                value={descricao}
                onChange={(e) => setDescricao(e.target.value)}
                className={campo}
              />
            )}
            {ativo ? (
              <button
                type="button"
                onClick={() => acao(() => pararCronometro())}
                className="min-h-12 rounded-xl bg-rose-500 font-semibold text-white"
              >
                Parar
              </button>
            ) : (
              <button
                type="button"
                onClick={() => acao(() => iniciarCronometro(local, descricao), () => setDescricao(''))}
                className="min-h-12 rounded-xl bg-[#f3e8ff] font-semibold text-[#1a1033]"
              >
                Iniciar
              </button>
            )}
            <p className="text-sm text-white/75">Não registre reuniões e eventos.</p>
          </section>

          <div className="flex flex-col gap-4">
            <div className="flex gap-2">
              <button type="button" disabled title="Em breve" className={`${botaoPrincipal} flex-1`}>
                + Registrar horas
              </button>
              <button
                type="button"
                aria-pressed={dados.naSede}
                onClick={() => acao(() => (dados.naSede ? desmarcarNaSede() : marcarNaSede()))}
                className={`${dados.naSede ? botaoVerde : botao} flex-1`}
              >
                {dados.naSede ? 'Saí da sede' : 'Estou na sede'}
              </button>
            </div>
            <p className="-mt-2 text-sm text-white/70">
              {nomesNaSede.length ? `Na sede agora: ${nomesNaSede.join(', ')}` : 'Ninguém marcou presença na sede agora.'}
            </p>

            <Cartao titulo="Tempo que já passou">
              {tempoQueJaPassou().map((t) => (
                <div key={t.nome} className="flex items-center gap-3">
                  <span className="w-16 text-sm">{t.nome}</span>
                  <div className="h-2 flex-1 overflow-hidden rounded-full bg-white/10">
                    <div className="h-full rounded-full bg-[#a78bfa]" style={{ width: `${t.pct}%` }} />
                  </div>
                  <span className="w-10 text-right font-mono text-xs text-white/70">{t.pct}%</span>
                </div>
              ))}
            </Cartao>
          </div>

          <Cartao titulo="Horas por dia">
            <div className="flex min-h-28 flex-1 items-end gap-2">
              {dados.dias.map((d, i) => (
                <div
                  key={d.dia}
                  title={`${horas(d.horasTotal)}h`}
                  className={`flex-1 rounded-t-md ${d.horasTotal ? 'bg-gradient-to-t from-[#6d28d9] to-[#d8b4fe]' : 'bg-white/15'}`}
                  style={{ height: `${Math.max(4, (d.horasTotal / maiorDia) * 100)}%` }}
                  aria-label={`${DIAS[i]}: ${horas(d.horasTotal)}h`}
                />
              ))}
            </div>
            <div className="flex gap-2 text-xs text-white/70">
              {DIAS.map((d, i) => (
                <span key={i} className="flex-1 text-center">
                  {d}
                </span>
              ))}
            </div>
          </Cartao>

          <Cartao titulo="Registros da semana">
            {dados.registros.length === 0 && <p className="text-white/70">Nenhum registro nesta semana ainda.</p>}
            {dados.registros.map((r) => (
              <div
                key={r.id}
                className="flex items-center justify-between gap-2 border-t border-white/10 pt-3 first:border-t-0 first:pt-0"
              >
                <div>
                  <b className="font-semibold">
                    {r.local === 'sede' ? 'Sede' : 'Online'}, {rotuloDia(dataEmBrasilia(r.inicio))} · {hora(r.inicio)} {r.fim ? `às ${hora(r.fim)}` : '(em andamento)'}
                  </b>
                  <p className="text-sm text-white/70">{r.descricao}</p>
                  {r.precisaRevisao && <Etiqueta tom="alerta">Em revisão pelo RH</Etiqueta>}
                </div>
                {r.fim && (
                  <button type="button" onClick={() => acao(() => cancelarRegistro(r.id))} className={`${botao} min-h-11`}>
                    Cancelar
                  </button>
                )}
              </div>
            ))}
          </Cartao>

          <Cartao titulo={`Resumo de ${nomeDoMes(mes)}`}>
            <div className="flex gap-2.5">
              {[
                [`${horas(ateAgora.reduce((t, s) => t + s.horasTotal, 0))}h`, 'Total no mês'],
                [`${horas(ateAgora.reduce((t, s) => t + s.horasSede, 0))}h`, 'Na sede'],
                [`${contadas.filter((s) => s.cumpriu).length} de ${contadas.length}`, 'Semanas cumpridas'],
              ].map(([v, l]) => (
                <div key={l} className="flex-1">
                  <p className="text-3xl font-light">{v}</p>
                  <p className="text-xs text-white/70">{l}</p>
                </div>
              ))}
            </div>
          </Cartao>

          <Cartao titulo={`Ranking de ${nomeDoMes(mes)}`}>
            <div className="flex items-center justify-between gap-3">
              <div>
                {dados.posicao.posicaoEJ > 0 ? (
                  <>
                    <p className="text-lg">
                      <span className="font-semibold text-[#d8b4fe]">{dados.posicao.posicaoEJ}º</span> de {dados.posicao.totalEJ} na EJ
                    </p>
                    <p className="text-lg">
                      <span className="font-semibold text-[#d8b4fe]">{dados.posicao.posicaoSetor}º</span> de {dados.posicao.totalSetor} no seu setor
                    </p>
                  </>
                ) : (
                  <p className="text-lg">Você ainda não está no ranking.</p>
                )}
                <p className="mt-1 text-sm text-white/70">Você vê só a sua posição.</p>
              </div>
              <Planeta tamanho={64} />
            </div>
          </Cartao>

          <Cartao titulo={`Semanas de ${nomeDoMes(mes)}`} className="border-[#8b5cf6]/40 bg-[#2a0f78]/60 md:col-span-2">
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
              {dados.semanasDoMes.map((s, i) => (
                <div
                  key={s.semana}
                  className={`flex flex-col gap-2 rounded-xl border p-3 ${s.semana === semana ? 'border-2 border-amber-300' : 'border-white/25'}`}
                >
                  <span className="font-mono text-xl text-white/60">{String(i + 1).padStart(2, '0')}</span>
                  <b className="font-semibold">{rotuloSemana(s.semana)}</b>
                  {s.semana <= semana && !s.dispensada && (
                    <span className="text-sm text-white/70">
                      Sede {horas(s.horasSede)}h · Total {horas(s.horasTotal)}h
                    </span>
                  )}
                  <EtiquetaSemana s={s} atual={semana} />
                </div>
              ))}
            </div>
          </Cartao>

          <button type="button" disabled title="Em breve" className={`${botao} md:col-span-2`}>
            Pedir ausência (requerimento)
          </button>
        </div>
      </main>
    </Fundo>
  )
}

export default PainelMembro
