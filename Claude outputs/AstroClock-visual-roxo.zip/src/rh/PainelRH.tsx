import { useCallback, useEffect, useState, type ReactNode } from 'react'
import { sair } from '../compartilhado/api/auth.ts'
import { listarMembros } from '../compartilhado/api/membros.ts'
import {
  abaixoDaMeta,
  cronometrosEmRevisao,
  listarRequerimentos,
  metasAtuais,
  percentualDaSemana,
  rankingDoMes,
  responderRequerimento,
  revisarCronometro,
  semanasSeguidasAbaixo,
} from '../compartilhado/api/rh.ts'
import { dataEmBrasilia, hora, horas, mesDe, rotuloDia, rotuloSemana, semanaAtual } from '../compartilhado/datas.ts'
import type {
  LinhaRanking,
  Membro,
  MembroAbaixoSeguido,
  Metas,
  Registro,
  Requerimento,
  ResumoMembroSemana,
} from '../compartilhado/tipos.ts'
import Cartao from '../compartilhado/ui/Cartao.tsx'
import { Carregando, Erro } from '../compartilhado/ui/Estados.tsx'
import Etiqueta from '../compartilhado/ui/Etiqueta.tsx'
import Fundo from '../compartilhado/ui/Fundo.tsx'
import { botao, botaoPrincipal } from '../compartilhado/ui/estilos.ts'

interface Dados {
  percentual: number
  abaixo: ResumoMembroSemana[]
  seguidas: MembroAbaixoSeguido[]
  revisao: Registro[]
  pendentes: Requerimento[]
  ranking: LinhaRanking[]
  metas: Metas
  membros: Membro[]
}

function Linha({ children }: { children: ReactNode }) {
  return <div className="flex items-center justify-between gap-3 border-t border-white/10 py-3 first:border-t-0 first:pt-0">{children}</div>
}

function PainelRH() {
  const semana = semanaAtual()
  const [dados, setDados] = useState<Dados | null>(null)
  const [erro, setErro] = useState<string | null>(null)
  const [erroAcao, setErroAcao] = useState<string | null>(null)

  const carregar = useCallback(() => {
    Promise.all([
      percentualDaSemana(semana),
      abaixoDaMeta(semana),
      semanasSeguidasAbaixo(semana),
      cronometrosEmRevisao(),
      listarRequerimentos('pendente'),
      rankingDoMes(mesDe(semana)),
      metasAtuais(),
      listarMembros(),
    ])
      .then(([percentual, abaixo, seguidas, revisao, pendentes, ranking, metas, membros]) => {
        setErro(null)
        setDados({ percentual, abaixo, seguidas, revisao, pendentes, ranking, metas, membros })
      })
      .catch((e: Error) => setErro(e.message))
  }, [semana])

  useEffect(() => {
    carregar()
  }, [carregar])

  function acao(fazer: () => Promise<unknown>) {
    setErroAcao(null)
    fazer()
      .then(carregar)
      .catch((e: Error) => setErroAcao(e.message))
  }

  if (erro || !dados) {
    return (
      <Fundo variante="brilho">
        <main className="relative">
          {erro ? (
            <Erro
              mensagem={erro}
              aoTentar={() => {
                setErro(null)
                carregar()
              }}
            />
          ) : (
            <Carregando />
          )}
        </main>
      </Fundo>
    )
  }

  const nomeDe = (id: string) => dados.membros.find((m) => m.id === id)?.nome ?? 'Membro'
  const seguidasDe = (id: string) => dados.seguidas.find((s) => s.membro.id === id)?.semanasSeguidas ?? 0

  const indicadores = [
    { rotulo: 'Cumpriram a meta', valor: `${dados.percentual}%`, alerta: false, barra: dados.percentual },
    { rotulo: 'Abaixo da meta', valor: String(dados.abaixo.length), alerta: false, barra: 0 },
    { rotulo: 'Abaixo 2+ semanas seguidas', valor: String(dados.seguidas.length), alerta: dados.seguidas.length > 0, barra: 0 },
    { rotulo: 'Cronômetros em revisão', valor: String(dados.revisao.length), alerta: false, barra: 0 },
    { rotulo: 'Requerimentos pendentes', valor: String(dados.pendentes.length), alerta: false, barra: 0 },
  ]

  return (
    <Fundo variante="brilho">
      <main className="relative mx-auto flex max-w-6xl flex-col gap-5 px-5 py-8 sm:px-7">
        <header className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="font-mono text-[11px] uppercase tracking-[0.3em] text-purple-300">Painel do RH · AstroClock</p>
            <h1 className="mt-2 text-3xl font-light tracking-tight sm:text-4xl">
              Semana de <span className="italic text-[#c084fc]">{rotuloSemana(semana)}</span>
            </h1>
          </div>
          <div className="flex gap-2">
            <button type="button" disabled title="Em breve" className={botaoPrincipal}>
              + Cadastrar membro
            </button>
            <button type="button" onClick={() => void sair()} className={botao}>
              Sair
            </button>
          </div>
        </header>

        {erroAcao && (
          <p role="alert" className="rounded-xl border border-rose-400/50 bg-rose-400/10 px-4 py-3 text-rose-200">
            {erroAcao}
          </p>
        )}

        <section className="grid grid-cols-2 gap-4 lg:grid-cols-5">
          {indicadores.map((i) => (
            <div
              key={i.rotulo}
              className={`flex flex-col justify-between gap-2 rounded-2xl border p-4 backdrop-blur-sm ${i.alerta ? 'border-rose-400/70 bg-rose-400/10' : 'border-white/15 bg-white/[0.04]'}`}
            >
              <p className="text-sm text-white/75">{i.rotulo}</p>
              <p className={`text-4xl font-light ${i.alerta ? 'text-rose-300' : ''}`}>{i.valor}</p>
              {i.barra > 0 && (
                <div className="h-1.5 overflow-hidden rounded-full bg-white/10">
                  <div className="h-full rounded-full bg-gradient-to-r from-[#7c3aed] to-[#d8b4fe]" style={{ width: `${i.barra}%` }} />
                </div>
              )}
            </div>
          ))}
        </section>

        <div className="grid gap-4 lg:grid-cols-3">
          <Cartao titulo="Quem ficou abaixo da meta" className="lg:col-span-2">
            {dados.abaixo.length === 0 && <p className="text-white/70">Ninguém abaixo da meta por enquanto.</p>}
            {dados.abaixo.map((r) => {
              const n = seguidasDe(r.membro.id)
              const faltaSede = r.horasSede < dados.metas.horasSede
              const faltaTotal = r.horasTotal < dados.metas.horasTotal
              return (
                <Linha key={r.membro.id}>
                  <div>
                    <b className="font-semibold">{r.membro.nome}</b>
                    <p className="text-sm text-white/70">
                      Sede {horas(r.horasSede)}h/{horas(dados.metas.horasSede)}h · Total {horas(r.horasTotal)}h/{horas(dados.metas.horasTotal)}h
                    </p>
                  </div>
                  {n >= 2 ? (
                    <Etiqueta tom="ruim">{`${n} semanas seguidas`}</Etiqueta>
                  ) : (
                    <Etiqueta tom="alerta">
                      {faltaSede && faltaTotal ? 'Falta sede e total' : faltaSede ? 'Falta sede' : 'Falta total'}
                    </Etiqueta>
                  )}
                </Linha>
              )
            })}
          </Cartao>

          <div className="flex flex-col gap-4">
            <Cartao titulo="Requerimentos">
              {dados.pendentes.length === 0 && <p className="text-white/70">Nenhum requerimento pendente.</p>}
              {dados.pendentes.map((r) => (
                <div key={r.id} className="border-t border-white/10 pt-3 first:border-t-0 first:pt-0">
                  <b className="font-semibold">{r.nomeMembro}</b>
                  <p className="mb-2 text-sm text-white/70">
                    {r.tipo === 'so_remoto' ? 'Só remoto' : 'Ausência total'} · {rotuloDia(r.inicio)} a {rotuloDia(r.fim)}
                  </p>
                  <div className="flex gap-2">
                    <button type="button" onClick={() => acao(() => responderRequerimento(r.id, true))} className={`${botaoPrincipal} min-h-11 flex-1`}>
                      Aprovar
                    </button>
                    <button type="button" onClick={() => acao(() => responderRequerimento(r.id, false))} className={`${botao} min-h-11 flex-1`}>
                      Reprovar
                    </button>
                  </div>
                </div>
              ))}
            </Cartao>

            <Cartao titulo="Ranking do mês">
              {dados.ranking.length === 0 && <p className="text-white/70">Sem horas registradas no mês.</p>}
              {dados.ranking.slice(0, 5).map((l) => (
                <div key={l.membro.id} className="flex items-center gap-3 py-0.5">
                  <span className="w-5 font-mono text-[#d8b4fe]">{l.posicao}</span>
                  <span className="flex-1">{l.membro.nome}</span>
                  <span className="font-mono text-sm text-white/75">{horas(l.horasTotal)}h</span>
                </div>
              ))}
            </Cartao>
          </div>
        </div>

        {dados.revisao.length > 0 && (
          <Cartao titulo="Cronômetros em revisão">
            {dados.revisao.map((r) => (
              <Linha key={r.id}>
                <div>
                  <b className="font-semibold">{nomeDe(r.membroId)}</b>
                  <p className="text-sm text-white/70">
                    {r.local === 'sede' ? 'Sede' : 'Online'} · {rotuloDia(dataEmBrasilia(r.inicio))}, {hora(r.inicio)}
                    {r.fim ? ` às ${hora(r.fim)}` : ''} · {r.descricao}
                  </p>
                </div>
                <div className="flex gap-2">
                  <button type="button" onClick={() => acao(() => revisarCronometro(r.id, true))} className={`${botaoPrincipal} min-h-11`}>
                    Aprovar
                  </button>
                  <button type="button" onClick={() => acao(() => revisarCronometro(r.id, false))} className={`${botao} min-h-11`}>
                    Reprovar
                  </button>
                </div>
              </Linha>
            ))}
          </Cartao>
        )}
      </main>
    </Fundo>
  )
}

export default PainelRH
